package lesson2.exercise_5;

public class Main {

	public static void main(String[] args) {
		String t = "Hello,strings can be fun. They have many uses.";
        //use the function split() with carefully chosen separators to produce:
		//[Hello, strings, can, be, fun, They, have, many, uses]
	}

}
