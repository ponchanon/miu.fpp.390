package lesson5.exercise_3;

public interface ValGetter {
	int getValue();
}
