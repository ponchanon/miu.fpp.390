package lesson4.exercise_5;

//inside... firstpackage
public class MyClass extends MySuperClass {

}


