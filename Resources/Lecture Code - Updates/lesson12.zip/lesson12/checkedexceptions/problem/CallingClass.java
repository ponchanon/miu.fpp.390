package lesson12.checkedexceptions.problem;

public class CallingClass {
	void writeInfo() {
		//need to handle possible exception
		//FileWriter fw = new FileWriter("MyFile");  //compiler error

	}
}
