package lesson2.regex.consolemanage;

public class ConsoleException extends Exception {
	 private static final long serialVersionUID = 1L;

	  public ConsoleException(Throwable t) {
	    super(t);
	  }
}
