package lesson12.improvedrational2;

public class NonPositiveDenomException extends Exception {
	public NonPositiveDenomException() {
		super();
	}
	public NonPositiveDenomException(String s) {
		super(s);
	}
	
}
