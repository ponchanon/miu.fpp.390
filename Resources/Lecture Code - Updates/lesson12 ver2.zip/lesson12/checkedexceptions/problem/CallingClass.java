package lesson12.checkedexceptions.problem;

import java.io.FileWriter;

public class CallingClass {
	void writeInfo() {
		//need to handle possible exception
		//FileWriter fw = new FileWriter("MyFile");  //compiler error

	}
}
