package lesson5.exercise_3;

@FunctionalInterface
public interface ValGetter {
	int getValue();
}
