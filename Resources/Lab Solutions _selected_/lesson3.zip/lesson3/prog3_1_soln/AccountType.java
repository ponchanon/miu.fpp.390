package prog3_1_soln;

public enum AccountType {	
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}
