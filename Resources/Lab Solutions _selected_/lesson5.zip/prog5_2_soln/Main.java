package prog5_2_soln;

public class Main {

	public static void main(String[] args) {
		Top top = new Top();
		Top.Middle tm = top.new Middle();
		Top.Middle.Bottom tmb = tm.new Bottom();
		System.out.println(tmb.b);

	}

}
