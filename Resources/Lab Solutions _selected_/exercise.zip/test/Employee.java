package lesson10.test;

import java.util.Objects;

public class Employee implements Comparable<Employee> {
	private String name;

	public Employee(String n) {
		name = n;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return name;
	}

	@Override
	public int compareTo(Employee o) {
		return this.getName().compareTo(o.getName());
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (o.getClass() != this.getClass())
			return false;

		Employee eo = (Employee) o;
		return this.getName().equals(eo.getName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.getName());
	}

}
