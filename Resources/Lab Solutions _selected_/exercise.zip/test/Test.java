package lesson10.test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

class MyJavaSet {
	//private TreeMap<Employee,Employee> map = new TreeMap<>(new NameComparator());
	//private TreeMap<Employee,Employee> map = new TreeMap<>();
	//private HashMap<Employee,Employee> map = new HashMap<>();
	
	//private TreeSet<Employee> set = new TreeSet<>(new NameComparator());
	private TreeSet<Employee> set = new TreeSet<>();
	//private HashSet<Employee> set = new HashSet<>();

	public void insert(Employee x) {
		set.add(x);
		//map.put(x, x);
	}

	public boolean remove(Employee x) {
		return set.remove(x);
		//map.remove(x);return true;
	}

	public boolean find(Employee x) {
		return set.contains(x);
		//return map.containsKey(x);
	}

	public List<Employee> asList() {
		return Arrays.asList(set.toArray(new Employee[0]));
		//return Arrays.asList(map.keySet().toArray(new Employee[0]));
	}
}

public class Test {

	public static void main(String[] args) {
		MyJavaSet set = new MyJavaSet();
		System.out.println("Inserting 5, 7, 3, 9, 10...");
		set.insert(new Employee("employee5"));
		set.insert(new Employee("employee7"));
		set.insert(new Employee("employee3"));
		set.insert(new Employee("employee9"));
		set.insert(new Employee("employee10"));
		System.out.println(set.asList());
		System.out.println("Removing 7");
		set.remove(new Employee("employee7"));
		System.out.println(set.asList());
		System.out.println("Is 5 in the tree? " + set.find(new Employee("employee5")));
		System.out.println("Is 7 in the tree? " + set.find(new Employee("employee7")));
	}
}
