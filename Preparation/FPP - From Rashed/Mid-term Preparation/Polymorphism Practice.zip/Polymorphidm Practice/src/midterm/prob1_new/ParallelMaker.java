package midterm.prob1_new;

class ParallelMaker extends Figure {
    
    String figure = "||";
    
    @Override
    public String getFigure() {
        return figure;
    }
}