package midterm.prob1_new;

class HatMaker extends Figure {
    String figure = "/\\";
    
     @Override
    public String getFigure() {
        return figure;
    }
}