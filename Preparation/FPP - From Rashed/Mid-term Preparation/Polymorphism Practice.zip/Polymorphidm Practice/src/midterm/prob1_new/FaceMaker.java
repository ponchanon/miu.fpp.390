package midterm.prob1_new;

public class FaceMaker extends Figure {
	
	String figure = ":)";
    
    @Override
    public String getFigure() {
        return figure;
    }

}
