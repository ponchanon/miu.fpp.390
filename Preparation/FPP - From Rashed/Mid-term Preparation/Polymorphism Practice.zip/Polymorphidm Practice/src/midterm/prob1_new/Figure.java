package midterm.prob1_new;

public abstract class Figure {
	
	public abstract String getFigure();

}
