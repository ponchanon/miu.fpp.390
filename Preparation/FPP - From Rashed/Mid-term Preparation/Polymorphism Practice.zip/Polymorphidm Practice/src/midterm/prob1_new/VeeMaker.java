package midterm.prob1_new;

class VeeMaker extends Figure {
    String figure = "\\/";
    
    @Override
    public String getFigure() {
        return figure;
    }
}