package assignment2;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Schur {
	
	public static boolean checkForSum(List<Integer> list, Integer z) {
		HashMap<Integer, Integer> h = new HashMap<Integer, Integer>();
		//Loads list elements into h
		int i = 1;
		for(Integer s : list) {
			h.put(i++, s);
		}
		
		for(int x : list) {
			int y = z - x;
			if(h.containsValue(y))
				return true;
		}
		return false;
	}

	public static void main(String[] args) {
		LinkedList<Integer> list = new LinkedList<Integer>();
        list.add(3);
        list.add(2);
        list.add(4);
        list.add(1);
		System.out.println(checkForSum(list, 3));
	}

}
