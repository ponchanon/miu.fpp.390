package assignment1;

import java.util.HashMap;

public class Employee {
	private String firstName;
	private String lastName;
	private HashMap<Integer, Double> salaryRecord = new HashMap<Integer, Double>();
	
	public void addEntry(String date, double salary) {
		// disallow null keys
		if (date == null)
			return;

		int h = makeHash(date);
		
		if(this.dublicateKey(h) == false)
			this.salaryRecord.put(h, salary);
	}
	
	private int makeHash(String str) {
		// convert key to an integer – assumes key not null
		int hashcode = str.hashCode();
		
		if(hashcode < 0) {
			hashcode = hashcode * -1;
		}
		// convert hashcode to a hashvalue – an array index
		int h = hash(hashcode);
		
		return h;
	}
	
	private int hash(int bigNum) {
		return (int) Math.abs(bigNum * 12);
	}
	
	public void printPaymentAmount(String date) {
		int h = makeHash(date);
		Double result = this.salaryRecord.get(h);
		StringBuilder output = new StringBuilder();
		if(result == null) {
			output.append(this.getFirstName());
			output.append(" ");
			output.append(this.getLastName());
			output.append(" did not receive a paycheck on ");
			output.append(date);
		}else {
			output.append(this.getFirstName());
			output.append(" ");
			output.append(this.getLastName());
			output.append(" was paid ");
			output.append(result);
			output.append(" on ");
			output.append(date);
		}
		System.out.println(output);
	}
	public void printAveragePaycheck() {
		Double result = (double) 0;
		StringBuilder output = new StringBuilder();
		
		for (Integer key : salaryRecord.keySet()) {
		    Double value = salaryRecord.get(key);
		    result += value;
		}
		
		Double avg = result / this.salaryRecord.size();
		output.append("Average paycheck for ");
		output.append(this.getFirstName());
		output.append(" ");
		output.append(this.getLastName());
		output.append(" was ");
		output.append(avg);
		
		System.out.println(output);
	}
	
	private boolean dublicateKey(int h) {
		for(Integer key : salaryRecord.keySet()) {
			if(key == h) {
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) {
		Employee e = new Employee();
		e.setFirstName("Jim");
		e.setLastName("Jones");
		for(int i = 1; i <= 12; ++i) {
			e.addEntry(i+"/15/2011", 3070+5*i);
		}
		e.printPaymentAmount("3/15/2011");
		e.printPaymentAmount("5/15/2010");
		e.printAveragePaycheck();
		
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
