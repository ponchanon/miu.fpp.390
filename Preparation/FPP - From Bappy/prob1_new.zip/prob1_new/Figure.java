package prob1_new;

public abstract class Figure {
	abstract String getFigure();
}
