package prob1_new;

class VeeMaker extends Figure{
    String figure = "\\/";
    
    public String getFigure() {
        return figure;
    }
}