package prob1_new;

class HatMaker extends Figure{
     String figure = "/\\";
    
    public String getFigure() {
        return figure;
    }
}