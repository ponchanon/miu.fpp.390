package prob1_new;

public class Driver {
	public static void main(String[] args) {
		Figure[] objArr = {new HatMaker(),
							new HatMaker(),
							new VeeMaker(),
							new ParallelMaker(),
							new FaceMaker()};		
		
		new Driver(objArr);
	}
	public Driver(Figure Object[] ){
		final String SPACE = " ";
		for(Figure o : Object){
				System.out.print(o.getFigure()+SPACE);
		}
	}

}
