package assignment2.employeeinfo;

public class OverdrawnAccountException extends Exception {

	private static final long serialVersionUID = 2325621889497782358L;

	public OverdrawnAccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OverdrawnAccountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
