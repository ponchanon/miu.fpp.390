package assignment1.closedcurve.good;

public class Circle extends ClosedCurve {
	double radius;
	public Circle(double radius) throws IllegalClosedCurveException {
		this.radius = radius;
		if(this.radius < 0)
			throw new IllegalClosedCurveException("The radius is invalid");
	}
	double computeArea() {
		return (Math.PI * radius * radius);
	}
}
