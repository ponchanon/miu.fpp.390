package assignment1.closedcurve.good;

public class IllegalClosedCurveException extends Exception {

	public IllegalClosedCurveException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IllegalClosedCurveException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
