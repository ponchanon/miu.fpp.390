package assignment1.closedcurve.good;

public class Rectangle extends ClosedCurve {

	private double width;
	private double length;
	public Rectangle(double width, double length) throws IllegalClosedCurveException{
		this.length = length;
		this.width = width;
		if(this.length < 0 || this.width < 0)
			throw new IllegalClosedCurveException("The length or width is invalid");
	}
	double computeArea() {
		return width*length;
	}
	


}
