package assignment3.employeeinfo;

abstract class Account {
	
	private final static double DEFAULT_BALANCE = 0.0;
	
	protected double balance;
	protected Employee employee;
	
	Account(Employee employee, double balance) {
		this.balance = balance;
		this.employee = employee;
	}

	Account(Employee employee) {
		this(employee, DEFAULT_BALANCE);
	}

	@Override
	public String toString() {
		return "Account type: " + getAccountType() + "\nCurrent bal: " + balance;
	}
	
	public void makeDeposit(double deposit) {
		balance += deposit;
	}
	
	public boolean makeWithdrawal(double amount) {
		if (amount <= balance) {
			balance -= amount;
			return true;
		}
		
		return false;
	}

	public double getBalance() {
		return balance;
	}
	
	public abstract AccountType getAccountType();

}
