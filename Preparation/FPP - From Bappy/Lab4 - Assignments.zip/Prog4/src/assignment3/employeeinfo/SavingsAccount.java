package assignment3.employeeinfo;

public class SavingsAccount extends Account {
	
	private final double INTEREST_RATE = 2.5;
	
	public SavingsAccount(Employee employee) {
		super(employee);
	}

	public SavingsAccount(Employee employee, double balance) {
		super(employee, balance);
	}

	@Override
	public double getBalance() {
		//2.5% monthly interest added
		double baseBalance = super.getBalance();
		double interest = baseBalance * INTEREST_RATE / 100; 
		return baseBalance + interest;
	}

	@Override
	public AccountType getAccountType() {
		return AccountType.SAVINGS;
	}

}
