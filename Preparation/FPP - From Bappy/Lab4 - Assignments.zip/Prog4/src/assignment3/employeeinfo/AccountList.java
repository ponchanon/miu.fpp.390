package assignment3.employeeinfo;

public class AccountList {
	
	private final int INITIAL_LENGTH = 3;
	
	private Account[] accounts; 
	private int size;
	
	public AccountList() {
		accounts = new Account[INITIAL_LENGTH];
		size = 0;
	}
	
	public void add(Account acc){
		if (size == accounts.length) {
			this.resize();
		}
		
		this.accounts[size] = acc;
		size++;
	}
	
	public Account get(int i){
		if (i < size) {
			return this.accounts[i];
		}
		
		return null;
	}
	
	public boolean find(Account acc){
		for (Account currAcc : this.accounts) {
			if (acc.getAccountType().equals(currAcc.getAccountType())) {
				return true;
			}
		}
		
		return false;
	}
	
	public void insert(Account acc, int pos){
		if (size == this.accounts.length) {
			resize();
		}
		
		if (pos < size) {
			for (int ind = size -1; ind >= pos; ind--) {
				this.accounts[ind + 1] = this.accounts[ind];
			}
			this.accounts[pos] = acc;
			this.size++;
		} else {
			System.out.println("Expected position is out of range and so adding at the last position");
			this.add(acc);
		}
	}
	
	public boolean remove(Account acc){
		for (int ind = 0; ind < this.accounts.length; ind++) {
			if (acc.getAccountType().equals(this.accounts[ind].getAccountType())) {
				this.accounts[ind] = null;
				
				//Shifting rest of the items by 1 step left
				for (int j = ind; j < this.accounts.length - 1; j++) {
					this.accounts[j] = this.accounts[j + 1];
					this.accounts[j + 1] = null;
				}
				
				//Adjusting the size
				this.size--;
				
				return true;
			}
		}
		
		return false;
	}
	
	
	private void resize(){
		System.out.println("Resizing...");
		
		Account[] newAccountArray = this.accounts.clone();
		
		this.accounts = new Account[this.size * 2];
		System.arraycopy(newAccountArray, 0, this.accounts, 0, size);
	}
	public String toString(){
		StringBuilder builder = new StringBuilder();
		
		builder.append("[");
	
		for(int ind = 0; ind < this.size; ind++) {			
			builder.append(this.accounts[ind]);
			
			if (ind != this.size-1) {
				builder.append(", ");
			}
		}
		
		builder.append("]");
		
		return builder.toString();
	}
	public int size() {
		return size;
	}

}
