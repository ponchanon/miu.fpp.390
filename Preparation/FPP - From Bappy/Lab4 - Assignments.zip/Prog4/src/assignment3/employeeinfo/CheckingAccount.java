package assignment3.employeeinfo;

public class CheckingAccount extends Account {
	
	private final double CHARGE = 5.0;
	
	public CheckingAccount(Employee employee) {
		super(employee);
	}

	public CheckingAccount(Employee employee, double balance) {
		super(employee, balance);
	}

	@Override
	public double getBalance() {
		//$5 monthly charge will be applied
		double baseBalance = super.getBalance();
		
		if (baseBalance < CHARGE) { 
			System.out.println("Account doen't have sufficient balance to check");
			return -1.0;
		}
		
		return baseBalance - CHARGE;
	}

	@Override
	public AccountType getAccountType() {
		return AccountType.CHECKING;
	}
	
	

}
