package assignment3.employeeinfo;

import java.time.LocalDate;
import Assignement3.MyStringList;

public class Employee {

	private AccountList accounts;
	private String name;
	private LocalDate hireDate;
	
	public Employee(String name, int yearOfHire, int monthOfHire, int dayOfHire){
		this.accounts = new AccountList();
		this.name = name;
		hireDate = LocalDate.of(yearOfHire, monthOfHire, dayOfHire);
	}

		
	public String getName() {
		return name;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void createNewChecking(double startAmount) {
		this.accounts.add(new CheckingAccount(this, startAmount));
	}

	public void createNewSavings(double startAmount) {
		this.accounts.add(new SavingsAccount(this, startAmount));		
	}

	public void createNewRetirement(double startAmount) {
		this.accounts.add(new RetirementAccount(this, startAmount));
	}

	public String getFormattedAcctInfo() {
		String accountBalanceSummary = "ACCOUNT INFO FOR " + this.name + ": \n";
		
		for (int i = 0; i < this.accounts.size(); i++) {
			Account currAcc = this.accounts.get(i);
			
			if (currAcc != null && currAcc.getBalance() > 0.0) {
				accountBalanceSummary += "\n" + currAcc.toString();
			}
		}
		
		return accountBalanceSummary;
	}
	public void deposit(Account account, double amt) {
		if (account != null) {
			account.makeDeposit(amt);
		} else {
			System.out.println("Not a valid account to withdraw");
		}
	}
	public boolean withdraw(Account account, double amt){
		if (account != null) {
			account.makeWithdrawal(amt);
			return true;
		} else {
			System.out.println("Not a valid account to withdraw");
		}
		
		return false;
	}
	
	public MyStringList getNamesOfAccounts() {
		MyStringList lst = new MyStringList();
		for (int i = 0; i < accounts.size(); i++) {
			lst.add(accounts.get(i).getAccountType().getValue());
		}
		return lst;
	}

}
