package assignment3.employeeinfo;

public class RetirementAccount extends Account {
	
	public RetirementAccount(Employee employee) {
		super(employee);
	}

	public RetirementAccount(Employee employee, double balance) {
		super(employee, balance);
	}

	@Override
	public boolean makeWithdrawal(double amount) {
		double penalty = this.balance * 2 / 100; //2% penalty applied

		if (amount <= (balance + penalty)) {
			balance -= (amount + penalty);
			return true;
		}

		System.out.println("Insufficiant balance to do the withdrawal operation");
		return false;
	}

	@Override
	public AccountType getAccountType() {
		return AccountType.RETIREMENT;
	}

}