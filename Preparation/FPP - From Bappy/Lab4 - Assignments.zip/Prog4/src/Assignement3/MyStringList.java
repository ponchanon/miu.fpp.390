package Assignement3;

public class MyStringList {
	private final int INITIAL_LENGTH = 2;
	private String[] strArray; 
	private int size;
	
	public MyStringList() {
		strArray = new String[INITIAL_LENGTH];
		size = 0;
	}
	
	public void add(String s){
		if(size == strArray.length) {
			this.resize();
		}
		
		this.strArray[size++] = s;
	}
	
	public String get(int i){
		if(i < size) {
			return this.strArray[i];
		}
		return null;
	}
	
	public boolean find(String s){
		
		for(int i = 0; i < this.strArray.length; ++i) {
			if(s.equals(this.strArray[i])) {
				return true;
			}
		}
		
		return false;
	}
	
	public void insert(String s, int pos){
		if(size == strArray.length) {
			this.resize();
		}
		
		if(pos < size) {
			for(int i = size-1; i > pos; i--) {
				this.strArray[i + 1] = this.strArray[i];
			}
			
			this.strArray[pos] = s;
			this.size++;
		}else {
			this.add(s);
		}
	}
	
	public boolean remove(String s){
		for(int i = 0; i < this.strArray.length; ++i) {
			if(s.equals(this.strArray[i])) {
				
				this.strArray[i] = null;
				
				// Shifting all the values
				for(int j = i; j < this.strArray.length - 1; j++) {
					this.strArray[j] = this.strArray[j+1];
					this.strArray[j+1] = null;
				}
				
				// Adjusting the size
				this.size--;
				
				return true;
			}
		}
		return false;
	}
	
	
	private void resize(){
		System.out.println("Resizing...");
		
		// Resize the array
		String[] newStrArray = this.strArray.clone();
		this.strArray = new String[size*2];
		System.arraycopy(newStrArray, 0, this.strArray, 0, size);
		
	}
	public String toString(){
		StringBuilder builder = new StringBuilder();
		builder.append("[");
		
		for(int i = 0; i < this.size; ++i) {
			builder.append(this.strArray[i]);
			
			if(i != this.size-1) {
				builder.append(", ");
			}
		}
		
		builder.append("]");
		
		return builder.toString();
	}
	public int size() {
		return size;
	}

	public static void main(String[] args){
		MyStringList l = new MyStringList();
		l.add("Bob");
		l.add("Steve");
		l.add("Susan");
		l.add("Mark");
		l.add("Dave");
		System.out.println("The list of size "+l.size()+" is "+l);
		l.remove("Mark");
		l.remove("Bob");
		System.out.println("The list of size "+l.size()+" is "+l);
		l.insert("Richard",3);
		System.out.println("The list of size "+l.size()+" after inserting Richard into pos 3 is "+l);
		l.insert("Tonya",0);
		System.out.println("The list of size "+l.size()+" after inserting Tonya into pos 0 is "+l);		
	}

}
