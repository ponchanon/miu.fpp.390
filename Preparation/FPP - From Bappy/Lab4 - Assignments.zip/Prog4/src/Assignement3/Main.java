package Assignement3;

import java.util.Scanner;

import assignment3.employeeinfo.Employee;

public class Main {
	Employee[] emps = null;
	public static void main(String[] args) {
		new Main();
	}
	Main(){
		emps = new Employee[3];
		emps[0] = new Employee("Jim Daley", 2000, 9, 4);
		emps[1] = new Employee("Bob Reuben", 1998, 1, 5);
		emps[2] = new Employee("Susan Randolph", 1997, 2,13);
		
		emps[0].createNewChecking(10500);
		emps[0].createNewSavings(1000);
		emps[0].createNewRetirement(9300);
		emps[1].createNewChecking(34000);
		emps[1].createNewSavings(27000);
		emps[2].createNewChecking(10038);
		emps[2].createNewSavings(12600);
		emps[2].createNewRetirement(9000);	
		
				
		Scanner sc = new Scanner(System.in);
		
		System.out.println("A. See a report of all account.");
		System.out.println("B. Make a deposit.");
		System.out.println("C. Make a withdrawal.");
		System.out.println("Make a selection (A/B/C):");
		
		String answer = sc.next();
		if(answer.equalsIgnoreCase("A")) {
			String info = getFormattedAccountInfo();
			System.out.println(info);
		} else if(answer.equalsIgnoreCase("B")
					|| answer.equalsIgnoreCase("C")) {
			int index = 0;
			for (Employee em : emps) {
				System.out.println(index + ". " + em.getName());
				index++;
			}
			System.out.print("Select an employee (type a number):");
			int employeeNumber = Integer.parseInt(sc.next());
			Employee currEmp = emps[employeeNumber];
			
			System.out.println("\n");
			MyStringList accountTypes = currEmp.getNamesOfAccounts();
			for (int i = 0; i < accountTypes.size(); i++) {
				System.out.println(i + ". " + accountTypes.get(i));
			}
			System.out.print("Select an account (type a number):");
			int accountTypeNum = Integer.parseInt(sc.next());
			
			System.out.println("\n");
			
			if (answer.equalsIgnoreCase("B")) {
				System.out.print("Deposit amount:");
				double depositedAmount = Double.parseDouble(sc.next());
				
				System.out.println("$" + depositedAmount + " has been deposited in the ");
				System.out.println(accountTypes.get(accountTypeNum) + " acccount of " + currEmp.getName());
			} else {
				System.out.print("Withdrawal amount:");
				double withdrawalAmount = Double.parseDouble(sc.next());
				
				System.out.println("$" + withdrawalAmount + " has been withdrawn from the ");
				System.out.println(accountTypes.get(accountTypeNum) + " acccount of " + currEmp.getName());
			}
		} else {
			//do nothing..the application ends here
		}	
	}
	String getFormattedAccountInfo(){
		String formattedString = "";
		
		for (Employee employee : this.emps) {
			formattedString += employee.getFormattedAcctInfo() + "\n\n";
		}
		
		return formattedString;
	}
}
