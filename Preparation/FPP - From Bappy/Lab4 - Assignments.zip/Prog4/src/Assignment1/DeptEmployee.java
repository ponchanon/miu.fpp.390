package Assignment1;

import java.time.LocalDate;

public class DeptEmployee {
	private String name;
	private LocalDate hireDate;
	protected double salary;
	
	public DeptEmployee(String name, double salary, int yearOfHire, int monthOfHire, int dayOfHire) {
		this.setName(name);
		this.salary = salary;
		this.setHireDate(LocalDate.of(yearOfHire, monthOfHire, dayOfHire));
	}
	
	public double computeSalary() {
		return this.salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}
	
}
