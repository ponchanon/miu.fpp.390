package Assignment1;

public class Professor extends DeptEmployee {
	private int numberOfPublications;
	
	public Professor(String name, double salary, int yearOfHire, int monthOfHire, int dayOfHire){
		super(name, salary, yearOfHire, monthOfHire, dayOfHire);
	}
	
	public int getNumberOfPublications() {
		return this.numberOfPublications;
	}
	
	public void setNumberofPublications(int num) {
		this.numberOfPublications = num;
	}
}
