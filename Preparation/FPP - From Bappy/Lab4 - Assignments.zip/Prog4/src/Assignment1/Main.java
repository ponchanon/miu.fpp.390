package Assignment1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		DeptEmployee[] department = new DeptEmployee[5];
		
		department[0] = new Professor("Jim Daley", 2000, 2000, 9, 4);
		department[1] = new Professor("Bob Reuben", 1500, 1998, 1, 5);
		department[2] = new Professor("Susan Randolph", 1800, 1997, 2,13);
		department[3] = new Secretary("SD Bappi", 1000, 1997, 2,13);
		department[4] = new Secretary("Sujit Kumar", 1100, 1997, 2,13);
		
		((Professor) department[0]).setNumberofPublications(10);
		((Professor) department[1]).setNumberofPublications(10);
		((Professor) department[2]).setNumberofPublications(10);
		((Secretary) department[3]).setOvertimeHours(200);
		((Secretary) department[4]).setOvertimeHours(200);
		
		try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Do you want to see the sum of all salaries in the department? (y/n) ");
			String answer = sc.next();
			if(answer.equalsIgnoreCase("y")){
				double sum = 0;
				for(int i = 0; i < department.length; ++i) {
					sum += department[i].computeSalary();
				}
				System.out.println("The sum of the all salaries is:" + sum);
			}else {
				System.out.println("Thank you for using this application");
			}
		}
	}

}
