package Assignment1;

public class Secretary extends DeptEmployee {
	private double overtimeHours;
	
	public Secretary(String name, double salary, int yearOfHire, int monthOfHire, int dayOfHire){
		super(name, salary, yearOfHire, monthOfHire, dayOfHire);
	}
	
	public double getOvertimeHours() {
		return this.overtimeHours;
	}
	
	public void setOvertimeHours(double num) {
		this.overtimeHours = num;
	}
	
	public double computeSalary() {
		return salary + (12 * this.getOvertimeHours());
	}
}
