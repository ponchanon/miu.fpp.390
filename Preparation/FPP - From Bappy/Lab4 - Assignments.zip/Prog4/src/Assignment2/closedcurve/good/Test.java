package Assignment2.closedcurve.good;

public class Test {
	
	public static void main(String[] args) {

		ClosedCurve[] objects = {new Triangle(4,5,6),
								 new Square(3),
								 new Rectangle(3,7),
								 new Circle(3),
								 };
		//compute areas
		int i = 0;
		for(ClosedCurve cc : objects) {
			String type = "";
			switch (i) {
				case 0: 
					type = "Triangle";
					break;
				case 1: 
					type = "Square";
					break;
				case 2: 
					type = "Rectangle";
					break;
				default:
					type = "Circle";
			}
			i++;
			System.out.println("The area of this " + type + " is " + cc.computeArea());
		}
    
	}

}