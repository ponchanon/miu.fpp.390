package assignment7;


public enum AccountType {
	CHECKING, 
	SAVINGS, 
	RETIREMENT;
}

