package assignment5;

public class MyTable {
private Entry[] entries;
	


public MyTable() {
    entries = new Entry[26];
}
//returns the String that is matched with char c in the table
public String get(char c){
    //implement
    for(Entry e: entries) {

        if(e!=null && e.ch==c) {
            return e.toString();
        }
    }
    return null;
}
//adds to the table a pair (c, s) so that s can be looked up using c
public void add(char c, String s) {
    int castAscii = (int) c;
    Entry e = new Entry(s, c);
    entries[castAscii-97] = e;
    //implement
}
//returns a String consisting of nicely formatted display
//of the contents of the table
public String toString() {
    String s="";
    for(Entry e : entries) {
        if(e!=null) s += String.format("%s %n", e);
    }
    return s;
}

private class Entry {
    private char ch;
    private String str;
    Entry(String str, char ch){
        this.str=str;
        this.ch=ch;
        //implement
    }
    //returns a String of the form "ch->str"
    public String toString() {
        //implement
        return ch+"->"+str;
    }
}

}
