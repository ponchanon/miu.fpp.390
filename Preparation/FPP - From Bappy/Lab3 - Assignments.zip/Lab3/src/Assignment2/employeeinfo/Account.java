package Assignment2.employeeinfo;

import Assignment1.AccountType;

class Account {
	
	private final static double DEFAULT_BALANCE = 0.0;
	private double balance;
	AccountType acctType;// = AccountType.CHECKING;

	Account(Employee emp, AccountType checking, double balance) {
		this.acctType = checking;
		this.balance = balance;
	}
	
	public AccountType getAcctType() {
		return this.acctType;
	}
	
	public double getBalance() {
		return this.balance;
	}

	Account(Employee emp, AccountType acctType) {
		this(emp, acctType, DEFAULT_BALANCE);
	}

	public String toString() {
		return "type = " + acctType + ", balance = " + balance;
	}

	public void makeDeposit(double deposit) {
		this.balance += deposit;
	}

	public boolean makeWithdrawal(double amount) {
		if(amount < this.balance) {
			this.balance = this.balance - amount;
			return true;
		}
		return false;
	}
}
