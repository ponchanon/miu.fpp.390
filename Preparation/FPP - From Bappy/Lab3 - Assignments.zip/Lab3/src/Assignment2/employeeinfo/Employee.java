package Assignment2.employeeinfo;

import java.time.LocalDate;

import Assignment1.AccountType;

public class Employee {

	private Account savingsAcct;
	private Account checkingAcct;
	private Account retirementAcct;
	private String name;
	private LocalDate hireDate;
	
	public Employee(String name, int yearOfHire, int monthOfHire, int dayOfHire){
		this.name = name;
		hireDate = LocalDate.of(yearOfHire, monthOfHire, dayOfHire);
	}

	
	public void createNewChecking(double startAmount) {
		checkingAcct = new Account(this, AccountType.CHECKING, startAmount);
	}

	public void createNewSavings(double startAmount) {
		savingsAcct = new Account(this, AccountType.SAVINGS, startAmount);
		
	}

	public void createNewRetirement(double startAmount) {
		retirementAcct = new Account(this, AccountType.RETIREMENT, startAmount);
		
	}

	public String getFormattedAcctInfo() {
		StringBuilder result = new StringBuilder();
        result.append("ACCOUNT INFO FOR " + this.name + "\n\n");
        if(checkingAcct != null) {
        	result.append("Account type: checking\n");
            result.append("Current bal:" + checkingAcct.getBalance() + "\n");
        }
		if(savingsAcct != null) {
			result.append("Account type: savings\n");
	        result.append("Current bal:" + savingsAcct.getBalance() + "\n");    	
		}
		if(retirementAcct != null) {
			result.append("Account type: retirement\n");
	        result.append("Current bal:" + retirementAcct.getBalance() + "\n\n");
		}
        return result.toString();
	}
	public void deposit(AccountType acctType, double amt){
		switch (acctType) {
	        case CHECKING:
	            this.checkingAcct.makeDeposit(amt);
	            break;
	        case SAVINGS:
	            this.savingsAcct.makeDeposit(amt);
	            break;
	        case RETIREMENT:
	            this.retirementAcct.makeDeposit(amt);
	            break;
		}
	}
	public boolean withdraw(AccountType acctType, double amt){
		switch (acctType) {
	        case CHECKING:
	            return this.checkingAcct.makeWithdrawal(amt);
	        case SAVINGS:
	        	return this.savingsAcct.makeWithdrawal(amt);
	        case RETIREMENT:
	        	return this.retirementAcct.makeWithdrawal(amt);
	        default:
	        	return false;
		}
	}

}
