package Assignment1;

public class Main {

	public static void main(String[] args) {

		Employee e = new Employee("Subhra Dey", "Bappi", 1000, 1989, 3, 17);
		for(int i =0; i < e.getAccounts().length; ++i) {
			System.out.println(e.getAccounts()[i]);
		}
	}

}
