package Assignment1;

import java.time.LocalDate;

public class Employee {
	// instance fields
	private String name;
	private String nickName;
	private double salary;
	private LocalDate hireDay;
	private Account[] accounts = new Account[3];

	// constructor
	Employee(String name, String aNickName, double aSalary, int aYear, int aMonth, int aDay) {
		this.name = name;
		nickName = aNickName;
		salary = aSalary;
		hireDay = LocalDate.of(aYear, aMonth, aDay);
		
		// Create accounts
		getAccounts()[0] = new Account(this, AccountType.CHECKING, 300);
		getAccounts()[1] = new Account(this, AccountType.RETIREMENT, 300);
		getAccounts()[2] = new Account(this, AccountType.SAVINGS, 300);
	}

	// instance methods
	public String getName() {
		return name;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String aNickName) {
		nickName = aNickName;
	}
	public double getSalary() {
		return salary;
	}
	// needs to be improved
	public LocalDate getHireDay() {
		return hireDay;
	}
	public void raiseSalary(double byPercent) {
		double raise = salary * byPercent / 100;
		salary += raise;
	}
	private String format = "name = %s, salary = %.2f, hireDay = %s";
	
	public String toString() {
		return String.format(format, name, salary, Util.dateAsString(hireDay));
	}

	public Account[] getAccounts() {
		return accounts;
	}

	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}
}
