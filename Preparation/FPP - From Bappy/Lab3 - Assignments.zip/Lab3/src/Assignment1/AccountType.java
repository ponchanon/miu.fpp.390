package Assignment1;

public enum AccountType {
	CHECKING, SAVINGS, RETIREMENT;
}
