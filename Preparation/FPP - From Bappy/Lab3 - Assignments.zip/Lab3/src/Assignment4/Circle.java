package Assignment4;

public final class Circle {
	
	private double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	public double getRadius() {
		return radius;
	}
	
	public double computeArea() {
		double area = Math.PI * getRadius() * getRadius();
		return area;
	}

}
