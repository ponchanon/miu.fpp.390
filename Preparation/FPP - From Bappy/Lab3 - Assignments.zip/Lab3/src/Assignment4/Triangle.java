package Assignment4;

import java.util.Arrays;

public final class Triangle {
	
	private double base;
	private double height;
	private double x;
	private double y;
	private double z;
	
	public Triangle(double base, double height) {
		this.base = base;
		this.height = height;
	}
	
	public Triangle(double a, double b, double c) {
		double[] arr =  new double[] {a, b, c};
		Arrays.sort(arr);
		for(int i = 0; i < arr.length; ++i) {
			if(i == 0) {
				this.x = arr[i];
			}
			if(i == 1) {
				this.y = arr[i];
			}
			if(i == 2) {
				this.z = arr[i];
			}
		}
	}
	
	public double getBase() {
		return base;
	}
	
	public double getHeight() {
		return height;
	} 
	
	public double computeArea() {
		double area = 0.5 * this.base * this.height;
		return area;
	}
	
	public double computeH() {
		double u = (this.y * this.y - this.x * this.x +this.z * this.z) / (this.z * this.z);
		double h = Math.sqrt(y * y - u * u);
		return h;
	}

}
