package Assignment4;

public class Main {

	public static void main(String[] args) {
		//Compute Area of Rectangle
		Rectangle r = new Rectangle(15, 10);
		double rArea = r.computeArea();
		System.out.println("Area of Rectangle is " + rArea);
		
		//Compute Area of Triangle
		Triangle t = new Triangle(10, 15);
		double tArea = t.computeArea();
		System.out.println("Area of Triangle is " + tArea);
		
		//Compute Area of Circle
		Circle c = new Circle(10);
		double cArea = c.computeArea();
		System.out.println("Area of Circle is " + cArea);
		
		//Compute for extra credit
		Triangle h = new Triangle(10, 15, 12);
		double hCal = h.computeH();
		System.out.println("Calculation for the extra credit is " + hCal);
	}

}
