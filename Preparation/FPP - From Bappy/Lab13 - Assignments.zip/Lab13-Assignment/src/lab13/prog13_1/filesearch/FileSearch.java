package lab13.prog13_1.filesearch;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * //PSEUDO-CODE boolean searchForFile(Object file, Object startDir) { Object[]
 * fileSystemObjects = startDir.getContents(); for(Object o: fileSystemObjects)
 * { //base case if(isFile(o) && isSameFile(o,f)) { return true; }
 * 
 * if(isDirectory(o)) { searchForFile(file, o); } } //file not found in startDir
 * return false; }
 */
public class FileSearch {
	static boolean found = false;
	// Store the text that is found in the
	// file that is found in this String variable
	static String discoveredText = "";

	public static boolean searchForFile(String filename, String startDir) {
		
		File dir = new File(startDir);

		String[] fileSystemObjects = dir.list();
		for (String o : fileSystemObjects) {
			File fl = new File(startDir + File.separator + o);
			
			//base case
			if (fl.isFile() && o.equals(filename)) {
				FileReader fr = null;
				
				try {
					fr = new FileReader(fl);
					
					char[] buf = new char[2094];
					while (fr.read(buf) != -1) {
						discoveredText += String.valueOf(buf);
						System.out.println(discoveredText);
					}
					
					found = true;
					break;
				} catch (IOException e) {
					System.out.println("Error occurred while reading file" + e.getMessage());
				} finally {
					try {
						if (fr != null) {
							fr.close();
						}
					} catch (IOException e) {
						System.out.println("Unable to close file pointer");
					}
				}
			} else if (fl.isDirectory()) {
				searchForFile(filename, startDir+ File.separator + o);
			}
		}
		
		//file not found in startDir
		return found;
	}
	
	public static void main(String[] args) {
		FileSearch.searchForFile("seek.txt" , "/Users/md.rashedulbari/Downloads/testCode");
	}

}
