package lab6_3;

public enum AccountType {
	CHECKING,
	SAVINGS,
	RETIREMENT
}

