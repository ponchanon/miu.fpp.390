package lesson2.stringcompareto;

public class Test2 {

	public static void main(String[] args) {
		System.out.println("a".compareTo("b"));
		System.out.println("b".compareTo("a"));
		System.out.println("a".compareTo("a"));
	}

}
