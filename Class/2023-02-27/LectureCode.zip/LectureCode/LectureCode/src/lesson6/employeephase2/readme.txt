This demo shows how the app will look when completed.

Also good to go over the code that they will get in their
lab directory -- this is located in the labs directory.

DO NOT DISTRIBUTE TO STUDENTS -- this is for use by instructor
to introduce one of the Lesson 5 labs