package lesson4.defaultconstructor;

public class MyClass {
	int x = 2;
     //no constructors defined
	
	public static void main(String[] args) {
		new MyClass();
	}
}
