package lesson4.inclass.protectedpractice_soln;

public class MySuperClass {
	private String val = "val";
	protected String getVal() {
		return val;
	}
}
