package lesson4.inclass.protectedpractice;

//inside firstpackage
public class MySuperClass {
	private String val = "val";
	protected String getVal() {
		return val;
	}
}



