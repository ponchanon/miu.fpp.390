package lesson4.orderofexec_demo;

public class Main {

	public static void main(String[] args) {
		SubClass s = new SubClass();

	}

}
