package lesson4.closedcurve.good;

abstract public class ClosedCurve {
	abstract double computeArea();

}
