package lesson4.protectedex.try1.superpkg;

public class SuperClass {
	protected String getVal() {
		return "val";
	}
}
