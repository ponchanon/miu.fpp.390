package lesson4.protectedex.try1.objrefpkg;

import lesson4.protectedex.try1.superpkg.SuperClass;

public class ObjRefClass extends SuperClass {
	
}
