package lesson4.protectedex.try4.superpkg;

public class SuperClass {
	private String val;
	protected String getVal() {
		return val;
	}
}
