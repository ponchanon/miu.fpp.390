package lesson1.hello;

import javax.swing.JOptionPane;

public class Hello {
	public static void main(String[] args) {
		JOptionPane.showMessageDialog(null, "Hello John!");
	}
}

