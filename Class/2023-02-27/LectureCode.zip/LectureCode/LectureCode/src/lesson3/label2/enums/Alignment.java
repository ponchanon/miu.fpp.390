package lesson3.label2.enums;

public enum Alignment {
	LEFT, CENTER, RIGHT;
}
