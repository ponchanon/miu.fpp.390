package lesson12.exceptionhandlingdemo;

import java.io.IOException;

public class MyClass {
	public void myMethod() throws IOException {
		//method body not shown here
	}
}


