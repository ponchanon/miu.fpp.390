package lesson5.comparators.data;
import lesson5.comparators.*;
public class PersonData {
	public static Person[] personData 
	  = {new Person("Joe"), new Person("Bill"), 
			  new Person("Sue"), new Person("Alice")};
	
}
